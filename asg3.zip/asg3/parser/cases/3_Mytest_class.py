class MyPython():
  n=99;
  def h():
    for x in range(5):
      if x < 3:
        print x
      else:
        print x+1
  def m():  
    pass  
    def s():  
      print "" 

