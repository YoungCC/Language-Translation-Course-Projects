if 1:
  print "if"

while 1:
  print "while"

for x in range(3): 
  pass

try:
  print ""
except:
  pass
