def f():
  D = {'jack':100, 'rose':101}
  for x in range(3):
    print "hello"
  try:  
    print D[x]
  except:
    print "bad key"
  except:
    print ""
  for x in range(3):
      print x
