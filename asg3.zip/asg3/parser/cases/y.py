def y():
   try:
    print ""
   except:
    print "This is an error message!"
   finally:
    print "hhhh"

def z():
   try:
     x=3;
     if x<3:
       print ""
   except:
     print "This is an error message!"
   class MyClass:
     i = 12345

     def f(self):
       return 'hello world'
     def y(self):
       return 'hello world'

while 1:
   pass

class MyClass:
 i = 12345

 def f(self):
  return 'hello world'
 def y(self):
  return 'hello world'
   
y()


