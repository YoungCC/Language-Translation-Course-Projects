def h():
  try:
    pass 
    for x in range(3):
      if x < 3:
        print x
    for x in range(3):
      if x < 7:
        print x 
  except:
    y = 9;
    while(y > 0):
      print y
    while(y < 0):
      print "Opps"
  finally:
    pass
