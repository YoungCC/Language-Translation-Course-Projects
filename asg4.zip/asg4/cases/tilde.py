print ~2
print ~2/.5
print ~3*4.4
print ~2+(~4-3.3)
print ~8//3.45
print ~7%3
print ~6**5
