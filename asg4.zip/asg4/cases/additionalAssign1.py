x=11
y=8

x+=y
print x
print y

x-=y
print x
print y

x*=y
print x
print y

x/=y
print x
print y

x//=y
print x
print y

x%=y
print x
print y

x**=y
print x
print y
