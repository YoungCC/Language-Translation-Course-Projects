def f():
  return
print f()

x=9
def g():
  print x

g()


