x=3
y=-6
def f():
  x=10
  y=x
  y=x*y-x/y
  print x
  print y

f()
print x
print y

