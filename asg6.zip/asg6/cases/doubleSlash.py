print 5//2
print 18//21
print -18//21
print 18//-21
print -18//-21

print 8.7//4.5
print 3.3//5.6
print -3.3//5.6
print 3.3//-5.6
print -3.3//-5.6

print 8.9//3
print -8.9//3
print 8.9//-3
print -8.9//-3

print 3//4.5
print -3//4.5
print 3//-4.5
print -3//-4.5

print (-4.5)//3
print 8//(-1.0)
