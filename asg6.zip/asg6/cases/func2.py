x = 2
def f():
  print 6
  x = -1
  x += 1
  print x

f()
print x
