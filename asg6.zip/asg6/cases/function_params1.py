x=3
y=-6
def f(x, y):
  z=x*y-x/y
  w=x
  v=x+z 
  print z
  print w
  print v

f(2,8)
f(-1,6)

