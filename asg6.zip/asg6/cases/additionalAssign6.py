x= -9
y= -6.0

x+=y
print x
print y
print 3*x - y
print 2*y - 9*x

x-=y
print x
print y
print 2*x + 5*x
print 4*y + 8*y

x*=y
print x
print y
print (2*x) / (2 * y)
print x / 5*y

x/=y
print x
print y
print (2*x)/(y-5)
print 4*x/2*y

x//=y
print x
print y
print y**2
print x//3.4

x%=y
print x
print y

x**=y
print x
print y
