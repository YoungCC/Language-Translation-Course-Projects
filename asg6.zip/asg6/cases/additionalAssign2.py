x=7.6
y=14.5

x+=y
print x
print y

x-=y
print x
print y

x*=y
print x
print y

x/=y
print x
print y

x//=y
print x
print y

x%=y
print x
print y

x**=y
print x
print y
