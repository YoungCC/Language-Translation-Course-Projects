x=-2
y=8;
def f():
  global x,y;
  z = x+y+1;
  print z;

f()

  
