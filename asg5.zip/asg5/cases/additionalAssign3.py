x=6
y=9.9

x+=y
print x
print y

x-=y
print x
print y

x*=y
print x
print y

x/=y
print x
print y

x//=y
print x
print y

x%=y
print x
print y

x**=y
print x
print y

x=14.8
y=3

x+=y
print x
print y

x-=y
print x
print y

x*=y
print x
print y

x/=y
print x
print y

x//=y
print x
print y

x%=y
print x
print y

x**=y
print x
print y
