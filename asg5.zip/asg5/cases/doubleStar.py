print 15**2
print -15**2
print 15**-2
print -15**-2 

print 3.6**1.4
print -3.6**1.4
print 3.6**-1.4
print -3.6**-1.4

print 2.5**3
print -2.5**3
print 2.5**-3
print -2.5**-3

print 2**6.5
print -2**6.5
print 2**-6.5
print -2**-6.5

print (-4.5)**3
print 8**(-1.0)
